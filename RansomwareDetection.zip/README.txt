Use `make` to build
Will only build if libfuse is installed on machine